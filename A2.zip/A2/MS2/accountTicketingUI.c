/*
	==================================================
	 Assignment #2 Milestone #1:
	==================================================
	Name   :Tanishq Talreja
	ID     :126460203
	Email  :ttalreja@myseneca.ca
	Section:NCC
*/
#define _CRT_SECURE_NO_WARNINGS
//I/O lib
#include <stdio.h>
//for structure passsing
#include"account.h"
#include "accountTicketingUI.h"
//MAIN CODE STARTS FROM HERE ->->->->


//pause exec.
// Pause execution until user enters the enter key
void pauseExecution(void)
{
	printf("<< ENTER key to Continue... >>");
	clearStandardInputBuffer();
	putchar('\n');
}
//F1 to display header for summ

void  displayAccountSummaryHeader(void)
{
	printf("\nAcct# Acct.Type Birth\n");
	printf("----- --------- -----\n");
}

//F2 display header for the whole data
void displayAccountDetailHeader(void)
{
	//  formatting 
	printf("Acct# Acct.Type Birth Income      Country    Disp.Name       Login      Password\n");
	printf("----- --------- ----- ----------- ---------- --------------- ---------- --------\n");
}

//F3 to display the data for the summ up

void displayAccountSummaryRecord(const struct Account *account)
{
	//print statment

	printf("%05d %-9s %5d\n",account->accountnum, account->user == 'A' ? "AGENT" : "CUSTOMER",
							account->demographic.birthyear);
}

//F4 display the whole data

void displayAccountDetailRecord(const struct Account* account)
{
	int i;
	//print statements
	printf("%05d %-9s %5d $%10.2lf %-10s %-15s %-10s ", account->accountnum,
		account->user == 'A' ? "AGENT" : "CUSTOMER",
		account->demographic.birthyear,account->demographic.houseincome,account->demographic.country,
		account->userlogin.dispname,account->userlogin.name);

	//print loop for password
	for ( i = 0; account->userlogin.password[i] != '\0'; i++)
	{
		if (i % 2 == 1)
		{
			putchar('*');
		}
		else
		{
			printf("%c",account->userlogin.password[i]);
		}
	}
	putchar('\n');


}



//func to display the summary of records

void displayAllAccountSummaryRecords(const struct Account acc[], int size)
{
	int i;
	
	displayAccountSummaryHeader();

	for (i = 0; i < size ; i++) //loop till i<size and the array of accountnum is > 0
	{	//passing the array element by element to the funct
		
		if (acc[i].accountnum==0)
		{
			//do nothing
		}
		else
		{
			displayAccountSummaryRecord(&acc[i]);
		}
	}
	putchar('\n');
	pauseExecution();


}
//F5 display the detailed rec
void displayAllAccountDetailRecords(const struct Account acc[], int size)
{
	int i;
	putchar('\n');
	displayAccountDetailHeader();
	for (i = 0; i < size; i++) //loop till i<size and the array of accountnum is > 0
	{
		if (acc[i].accountnum == 0)
		{
			//do nothing
		}
		else
		{
			displayAccountDetailRecord(&acc[i]);
		}//passing the array element by element to the funct
		
	}
	putchar('\n');
	pauseExecution();

}

int findAccountIndexByAcctNum(int accountnum, const struct AccountTicketingData* accountTicketing, int input)
{
	int  i, find = 0, addr = 0;
	if (input == 1)
	{
		printf("\nEnter the account#: ");
		accountnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->ACCOUNT_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->accounts[i].accountnum==accountnum)
			{
				addr = i;
				find = 1;

			}
		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	else if (input == 0)
	{
		for (i = 0; i < accountTicketing->ACCOUNT_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->accounts[i].accountnum == accountnum)
			{
				find = 1;
				addr = i;
			}
		}
		if (find == 0)
		{
			addr = -1;
		}

	}

	return addr;
}


//MILESTONE 4 Starts


void menuAgent(struct AccountTicketingData* accountTicketing, const struct Account* accounts)
{
	//vars
	int selection, j, found = 0, accountnumber, search=-1;
	char delete;
	int addacount,maxaccount=0;

	do
	{
		//display name of agent
		printf("AGENT: %s (%05d)", accounts->userlogin.dispname, accounts->accountnum);
		//display menu option
		printf("\n==============================================");
		printf("\nAccount Ticketing System - Agent Menu");
		printf("\n==============================================");
		printf("\n1) Add a new account");
		printf("\n2) Modify an existing account");
		printf("\n3) Remove an account");
		printf("\n4) List accounts: summary view");
		printf("\n5) List accounts: detailed view");
		printf("\n----------------------------------------------");
		printf("\n6) List new tickets");
		printf("\n7) List active tickets");
		printf("\n8) Manage a ticket");
		printf("\n9) Archive closed tickets");
		printf("\n----------------------------------------------");
		printf("\n0) Logout\n");
		printf("\nSelection: ");
		//input and clearing buffer
		selection = getIntFromRange(0, 9);

		//switch case for menu
		switch (selection)
		{
		case 0:
			printf("\n### LOGGED OUT ###\n\n");
			//do nothing
			break;
		case 1:
			//logic for adding new account
			//binary search for acct num =0
			for (j = 0; j < accountTicketing->ACCOUNT_MAX_SIZE && found == 0; j++)
			{
				if (accountTicketing->accounts[j].accountnum == 0)
				{
					addacount = j;
					found = 1;
				}
			}
			
			//loop to search biggest account num
			for (j = 0; j < accountTicketing->ACCOUNT_MAX_SIZE ; j++)
			{
				if (accountTicketing->accounts[j].accountnum>maxaccount)
				{
					maxaccount = accountTicketing->accounts[j].accountnum;
				}
			}
			if (found == 0)
			{
				printf("\nERROR: Account listing is FULL, call ITS Support!");
			}
			else
			{
				putchar('\n');
				getAccount(&accountTicketing->accounts[addacount],maxaccount);
				getUserLogin(&accountTicketing->accounts[addacount].userlogin);
				getDemographic(&accountTicketing->accounts[addacount].demographic);
			}
			printf("\n*** New account added! ***\n");
			putchar('\n');
			pauseExecution();
			found = 0;

			break;
		case 2:
			//logic to update account and if not valid acctnum display error msg
			search = findAccountIndexByAcctNum(search,accountTicketing,1);
			//display error if !found
			if (search == -1)
			{
				printf("\n Error : Match not found!");
			}
			else
			{
				updateAccount(&accountTicketing->accounts[search]);
			}
			break;
		case 3:
			//input acc num and search for it
			printf("\nEnter the account#: ");
			accountnumber = getPositiveInteger();
			//binary search
			if (accounts->accountnum == accountnumber)
			{
				printf("\nERROR: You can't remove your own account!\n\n");
				pauseExecution();
			}
			else if (accounts->accountnum != accountnumber)
			{
				search = findAccountIndexByAcctNum(search, accountTicketing, 0);
				
				if (search == -1)
				{
					printf("\n Error : Match not found!");
				}
				else
				{

					displayAccountDetailHeader();
					displayAccountDetailRecord(&accountTicketing->accounts[search]);

					printf("\nAre you sure you want to remove this record? ([Y]es|[N]o): ");
					delete = getCharOption("YN");
					if (delete == 'N')
					{
						printf("\n*** No changes made! ***\n\n");
						pauseExecution();
					}

					else
					{
						accountTicketing->accounts[search].accountnum = 0; //set acctnum =0
						printf("\n*** Account Removed! ***\n\n");
						pauseExecution();
					}
				}
			}
			//if record found display header and ask for deletion
			break;

		case 4:
			displayAllAccountSummaryRecords(accountTicketing->accounts, accountTicketing->ACCOUNT_MAX_SIZE);
			break;

		case 5:
			displayAllAccountDetailRecords(accountTicketing->accounts, accountTicketing->ACCOUNT_MAX_SIZE);
			break;

		case 6:printf("\nFeature #6 currently unavailable!\n\n");
			pauseExecution();
			break;
		case 7:printf("\nFeature #7 currently unavailable!\n\n");
			pauseExecution();
			break;
		case 8:printf("\nFeature #8 currently unavailable!\n\n");
			pauseExecution();
			break;
		case 9:printf("\nFeature #9 currently unavailable!\n\n");
			pauseExecution();
			break;
		
		
		default:
			printf("Error!  invalid selection!\n\n");
			break;
		}
	} while (selection);
	
}

int menuLogin(const struct AccountTicketingData* accountTicketing)
{
	//vars 
	int selection=0, search=0, position=0;
	char input;
	do
	{
		//Display login menu
		printf("==============================================\n");
		printf("Account Ticketing System - Login\n");
		printf("==============================================\n");
		printf("1) Login to the system\n");
		printf("0) Exit application\n");
		printf("----------------------------------------------\n\n");
		printf("Selection: ");

		// call commonhelpers function for range thing
		selection = getIntFromRange(0, 1);

		//if returned selection =1 then ask for acct num.

		if (selection == 1)
		{
			printf("\nEnter your account#: ");
			scanf("%d", &search);
			
			search = findAccountIndexByAcctNum(search,&accountTicketing,0);
			if (search ==-1)
			{
				printf("\nERROR:  Access Denied.\n");
				putchar('\n');
				pauseExecution();
				putchar('\n');
				
			}
			else
			{
				position=search;
				selection = -1;
			}
		}
		//if user selects 0 then it will return -1
		else if (selection==0)
		{
			printf("\nAre you sure you want to exit? ([Y]es|[N]o): ");
			input = getCharOption("yYnN");
			if (input=='Y' || input == 'y')
			{
				position = -1;
				selection = -1;

			}
			else
			{
				selection = 0;
			}
			putchar('\n');
		}
		
		//loops exit when found=1 or selection =0
	} while (selection>=0);
	
	return position;
}

//menu for customer 
void menuCustomer(struct AccountTicketingData* accountTicketing, const struct Account* accounts)
{
	int selection,search;
	do
	{
		//display name of agent
		printf("CUSTOMER: %s (%05d)",accounts->userlogin.name,accounts->accountnum );
		//display menu option
		printf("\n==============================================");
		printf("\nCustomer Main Menu");
		printf("\n==============================================");
		printf("\n1) View your account detail");
		printf("\n2) List my tickets");
		printf("\n3) Create a new ticket");
		printf("\n4) Manage a ticket");
		printf("\n----------------------------------------------");
		printf("\n0) Logout\n");
		printf("\nSelection: ");
		selection = getIntFromRange(0, 4);
		switch (selection)
		{
		case 1:
			search = findAccountIndexByAcctNum(accounts->accountnum, accountTicketing, 0);
			putchar('\n');
			displayAccountDetailHeader();
			displayAccountDetailRecord(&accounts[search]);
			putchar('\n');
			pauseExecution();
			break;
		case 2:
			printf("\nFeature #2 currently unavailable!\n\n");
			pauseExecution();
			break;
		case 3:
			printf("\nFeature #3 currently unavailable!\n\n");
			pauseExecution();
			break;
		case 4:
			printf("\nFeature #4 currently unavailable!\n\n");
			pauseExecution();
			break;
		
		case 0:
			//do nothing
			printf("\n### LOGGED OUT ###\n\n");
			break;

		default:printf("\nERROR\n");
			break;
		}
	} while (selection);
}



//F1 for app start
void applicationStartup(struct AccountTicketingData *accountTicketing)
{
	int position,flag=0;
	do
	{
		
		position = menuLogin(accountTicketing->accounts,accountTicketing->ACCOUNT_MAX_SIZE);

		if (position < 0)
		{
			printf("==============================================");
			printf("\nAccount Ticketing System - Terminated");
			printf("\n==============================================\n");
			flag = 1;
		}

		if (position >= 0)
		{


			if (accountTicketing->accounts[position].user == 'A')
			{
				
				putchar('\n');
				menuAgent(&accountTicketing->accounts, &accountTicketing->accounts[position]); 
				
			}

			else 
			{
				putchar('\n');
				menuCustomer(&accountTicketing->accounts, &accountTicketing->accounts[position]);
				
			}

		}
		
	} while (flag==0);
	
	
	
	
}









