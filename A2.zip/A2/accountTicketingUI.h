/*
==================================================
Assignment #2 Milestone #1:
==================================================
Name : Tanishq Talreja
ID : 126460203
Email : ttalreja@myseneca.ca
Section : NCC
*/

#define _CRT_SECURE_NO_WARNINGS
#include "ticket.h"
#include "account.h"

#ifndef ACCOUNTUI_H_
#define ACCOUNTUI_H_

//ASSIGNMENT 2

struct AccountTicketingData
{
	struct Account* accounts; // array of accounts
	const int ACCOUNT_MAX_SIZE; // maximum elements for account array
	struct Ticket* tickets; // array of tickets
	const int TICKET_MAX_SIZE; // maximum elements for ticket array
};
//pause exec.
// Pause execution until user enters the enter key
void pauseExecution(void);
//F1 to display header for summ

void  displayAccountSummaryHeader(void);

//F2 display header for the whole data

void displayAccountDetailHeader(void);

//F3 to display the data for the summ up

void displayAccountSummaryRecord(const struct Account* account);

//F4 display the whole data

void displayAccountSummaryRecord(const struct Account* account);
//F2 for  menu login

int menuLogin(const struct AccountTicketingData* accountTicketing);
//F4 search function
int findAccountIndexByAcctNum(int accountnum, const struct AccountTicketingData* accountTicketing, int input);

//milestone 4
//F1 for app start
void applicationStartup(struct AccountTicketingData* accountTicketing);

// F3 for menu of agent
//accounts is for the agent that has logged in
void menuAgent(struct AccountTicketingData* accountTicketing, const struct Account* accounts);

//F5 display the detailed rec
void displayAllAccountDetailRecords(const struct Account acc[], int size);

//F6 display the summary of rec
void displayAllAccountSummaryRecords(const struct Account acc[], int size);

//menu for customer similar to the agent one
void menuCustomer(struct AccountTicketingData* accountTicketing, const struct Account* accounts, const struct Ticket* ticket);
// to check whether the details of the user matches in given record or not so as make it more secure and not displaying errors
// to save it from hackers.
int AuthenticationCheck(const struct AccountTicketingData* accountTicketing);

//a function for the customertickets to display only the tickets that are filed by the customer and ask if he wants to
//display them.
void customertickets(const struct AccountTicketingData* accountTicketing, int accountnum);

//a basic header function which is called in the agent's ticket section
void AgentTicketHeader(void);

//a function for the agent menu to display the new tickets that are opened and have only one message.means have value of 1 of message and status of ticket.
void DisplayNewTickets(const struct AccountTicketingData* accountTicketing);

//ask for the user to display details and content of ticket 
int DisplayTicketDetails(const struct AccountTicketingData* accountTicketing);

//a function for the agent's menu to display all the active tickets that are opened means have status of ticket as 1
void DisplayAllActiveTickets(const struct AccountTicketingData* accountTicketing);




#endif // !ACCOUNTUI_H_
