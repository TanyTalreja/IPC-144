/*
==================================================
Assignment #2 Milestone #1:
==================================================
Name : Tanishq Talreja
ID : 126460203
Email : ttalreja@myseneca.ca
Section : NCC
*/

#define _CRT_SECURE_NO_WARNINGS
//LIBS

//Safegaurding header file

#ifndef TICKETINGSYSTEM_H_
#define TICKETINGSYSTEM_H_

#define MAXSTRINGSIZE 150
#define MINSTRINGSIZE 30
#define MAXMESSAGERECORDS 20

//DEFINING THE STRUCTURE FOR MESSAGE type as per documentation

struct Message
{
	char accountType;
	char messageAuthor[MINSTRINGSIZE+1];
	char message[MAXSTRINGSIZE+1];
};

//DEFINIG A STRUCTURE TYPE FRO THE TICKETING
struct Ticket
{
	int ticketNum;
	int accountNum;
	int statusofTicket;
	char subject[MINSTRINGSIZE+1];
	int numofMessage;
	struct Message message[MAXMESSAGERECORDS];
};


void newCustomerTicket(struct Account accounts[], struct Ticket* ticket, int size);

void activeTicketMenu(struct Ticket* ticket, struct Account* accounts);



void addMessage(struct Ticket* ticket, struct Account* accounts);

void closeTicket(struct Ticket* ticket, const struct Account accounts[]);
void agentTicketManage(struct Ticket* ticket, const struct Account accounts[]);
int findTicketIndexByAcctNum(const struct AccountTicketingData* accountTicketing, int accountnum);




#endif // !TICKETINGSYSTEM_H_
