
/*
	==================================================
	 Assignment #2 Milestone #1:
	==================================================
	Name   :Tanishq Talreja
	ID     :126460203
	Email  :ttalreja@myseneca.ca
	Section:NCC
*/

#define _CRT_SECURE_NO_WARNINGS

#include "ticket.h"
#include "accountTicketingUI.h"
#include "commonHelpers.h"
#include<stdio.h>
#include<string.h>

//main code for logic starts from here

// MILESTONE #3
//a function to find the ticket number exist or not
int findTicketIndexByAcctNum(const struct AccountTicketingData *accountTicketing, int accountnum)
{
	int  i, find = 0, addr = 0;
	int ticketnum;
	
	
	if (accountnum=-1)
	{
		printf("\nEnter ticket number: ");
		ticketnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			
				if (accountTicketing->tickets[i].ticketNum == ticketnum)
				{
					addr = i;
					find = 1;

				}
			

		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	else
	{
		printf("\nEnter ticket number: ");
		ticketnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].accountNum == accountnum)
			{
				if (accountTicketing->tickets[i].ticketNum == ticketnum)
				{
					addr = i;
					find = 1;

				}
			}

		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	return addr;
}

//function to create a new ticket and assign value to new ticket
void newCustomerTicket(struct Account accounts[],struct Ticket* ticket,int size)
{
	//vars
	int i, found = 0, addticket, maxticket=0;



	//loop to find the empty space for ticketnum
	for (i = 0; i <size; i++)
	{
		if (ticket[i].ticketNum == 0)
		{
			addticket = i;
			found = 1;
		}
	}

	//loop to search biggest ticket num
	for (i = 0; i < size; i++)
	{
		if (ticket[i].ticketNum > maxticket)
		{
			maxticket = ticket[i].ticketNum;
		}
	}
	//if there is no empty space found then reporth the user
	if (found == 0)
	{
		printf("\nERROR: Account listing is FULL, call ITS Support!\n\n");
		pauseExecution();
	}
	//keypoints: set status to 1,must enter message and subject,data should be stored at position by addticket,set customer as first message ,save name as by the customer
	else
	{
		printf("\nNew Ticket (Ticket#:%06d)\n",maxticket+1);
		printf("----------------------------------------\n");
		
		//ask for the message
		printf("Enter the ticket SUBJECT (30 chars. maximum): ");
		getCString(ticket[addticket].subject, 3, MINSTRINGSIZE);
		printf("\nEnter the ticket message details (150 chars. maximum). Press the ENTER key to submit:\n");
		getCString(ticket[addticket].message->message, 3, MAXSTRINGSIZE);
		//set status of ticket as active
		ticket[addticket].statusofTicket = 1;
		//set autor of message as customer
		ticket[addticket].message->accountType = 'C';
		//set number of message as 1
		ticket[addticket].numofMessage = 1;
		//set the author as the user and account num as accountnumber
		ticket[addticket].accountNum = accounts->accountnum;
		//print the end statement
		ticket[addticket].ticketNum = maxticket + 1;
		//copy the name of autor of message as the user
		strcpy(ticket[addticket].message->messageAuthor, accounts->userlogin.dispname);
		//print the end statement
		printf("\n*** New ticket created! ***\n\n");
		pauseExecution();


	}
}


//a menu to modify the active tickets by the user

void activeTicketMenu(struct Ticket *ticket, struct Account *accounts)
{
	//vars
	int selection;
	
	do
	{
		
		//after rcving and checking the ticket
		printf("\n----------------------------------------\n");
		printf("Ticket %06d - Update Options\n", ticket->ticketNum);
		printf("----------------------------------------\n");
		//print details of the ticket
		printf("Status  : %s\n", ticket->statusofTicket == 1 ? "ACTIVE" : "CLOSED");
		printf("Subject : %s\n", ticket->subject);
		printf("----------------------------------------\n");
		//after printing the statement now display the menu
		//menu options
		printf("1) Modify the subject"); 
		printf("\n2) Add a message");
		printf("\n3) Close ticket");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 3);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			printf("\nEnter the revised ticket SUBJECT (30 chars. maximum): ");
			getCString(ticket->subject, 3, MINSTRINGSIZE);
			break;
		case 2:
			addMessage(ticket,accounts);
			
			break;
		case 3:

			if (ticket->statusofTicket == 0)

			{
				printf("\nERROR: Ticket is already closed!\n");
			}
			else
			{
				closeTicket(ticket, accounts); //calling the closing of ticket
				selection = 0;
			}
			break;

		default:
			printf("Error!  invalid selection!\n");
			break;
		}
	} while (selection);

	putchar('\n');
}

//adds message if user wishes to
void addMessage(struct Ticket *ticket, struct Account *accounts)
{
	int i,search = 0;
	//check whether there are spaces for message as limit is 20 if nummessage = 20 display error else let user enter message
	for (i = 0; i < MAXMESSAGERECORDS && search == 0; i++)
	{
		if (strlen(ticket->message[i].message)==0)
		{
			search = i;
		}
		
	}

	if (search > 0)
	{
		//strcpy(ticket->message[search].accountType, accounts->user);
		if (accounts->user=='C')
		{
			ticket->message[search].accountType = 'C';
		}
		else
		{
			ticket->message[search].accountType = 'A';
		}
		strcpy(ticket->message[search].messageAuthor,accounts->userlogin.dispname);
		printf("\nEnter the ticket message details (150 chars. maximum). Press the ENTER key to submit:\n");
		getCString(ticket->message[search].message, 3, MAXSTRINGSIZE);
		ticket->numofMessage++;
	}

	else
	{
		printf("\nERROR: Message limit has been reached, call ITS Support!\n");

	}
}

//closes ticket for the user

void closeTicket(struct Ticket* ticket, const struct Account accounts[])
{
	char status;
	char endmessage;
	//print to close ticket or not
	
	
		printf("\nAre you sure you CLOSE this ticket? ([Y]es|[N]o): ");
		status = getCharOption("YN");
		//print to ask for an end message or not
		if (ticket->numofMessage!=MAXMESSAGERECORDS)
		{
			printf("\nDo you want to leave a closing message? ([Y]es|[N]o): ");
			endmessage = getCharOption("YN");
			if (endmessage == 'Y' && ticket->numofMessage != MAXMESSAGERECORDS)
			{
				addMessage(ticket, accounts);
			}
		}
		//only enter message if there is space else display error
		
		if (status == 'Y')
		{
			ticket->statusofTicket = 0;
		}
		printf("\n*** Ticket closed! ***\n");
	
	
	
}



void agentTicketManage(struct Ticket* ticket, const struct Account accounts[])
{
	//vars
	int selection;
	char choice;

	do
	{

		//after rcving and checking the ticket
		printf("\n----------------------------------------\n");
		printf("Ticket %06d - Update Options\n", ticket->ticketNum);
		printf("----------------------------------------\n");
		//print details of the ticket
		printf("Status  : %s\n", ticket->statusofTicket == 1 ? "ACTIVE" : "CLOSED");
		printf("Subject : %s\n", ticket->subject);
		printf("Acct#   : %d\n",ticket->accountNum);
		printf("Customer: %s\n", ticket->message->messageAuthor);
		printf("----------------------------------------\n");
		//after printing the statement now display the menu
		//menu options
		printf("\n1) Add a message");
		printf("\n2) Close ticket");
		printf("\n3) Re-open ticket");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 3);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			
			if (ticket->statusofTicket==1)
			{
				addMessage(ticket, accounts);
				pauseExecution();
			}
			else
			{
				printf("\nERROR: Ticket is closed - new messages are not permitted.\n");
			}

			break;
		case 2:
			if (ticket->statusofTicket==0)
			
			{
				printf("\nERROR: Ticket is already closed!\n\n");
			}
			else
			{
				closeTicket(ticket, accounts); //calling the closing of ticket
				selection = 0;
			}
			break;
		case 3:

			if (ticket->statusofTicket == 0)
			{
				printf("\nAre you sure you RE-OPEN this closed ticket? ([Y]es|[N]o): ");
				choice = getCharOption("YN");
				if (choice=='Y')
				{
					ticket->statusofTicket = 1;
					printf("\n*** Ticket re-opened! ***\n");
				}
			}
			else
			{
				printf("\nERROR: Ticket is closed - new messages are not permitted.\n");
			}

			break;

		default:
			printf("Error!  invalid selection!\n");
			break;
		}
	} while (selection);

	putchar('\n');
}

//THINGS TO DO
//in acdd message change author as to the person who call it or whose ticket is going on --done
//add that after every 5 message there is pauseexec --done
//add agent menu display things --done
//delete extra newline after pause exet in customer menui
//