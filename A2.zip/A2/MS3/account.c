/*
	==================================================
	 Assignment #2 Milestone #1:
	==================================================
	Name   :Tanishq Talreja
	ID     :126460203
	Email  :ttalreja@myseneca.ca
	Section:NCC
*/
#define _CRT_SECURE_NO_WARNINGS
//MACROS
#define MIN 3
#define MAX 31

//defined libs
#include<ctype.h>
#include<string.h>

//DEFINING HEADER FILES
#include "account.h"
#include "commonHelpers.h"

//HEADERFILES INCLUDED

//MAINCODE STARTS HERE ->->->
void passwordcheck(char *string)
{
	int i, flag = 0,digit=0,upper=0,lower=0,other=0;
	char word[51];
	const char symbols[] = "!@#$%^&*";
	do
	{
		printf("\nEnter the password (must be 8 chars in length): ");
		getCString(word, 8, 8);
		for (i = 0; word[i] != '\0'; i++)
		{
			if (isdigit(word[i]) > 0)
			{
				// increment counter
				digit++;
			}
			// check for uppercase
			else if (isupper(word[i]) > 0)
			{
				// increment counter
				upper++;
			}
			// check for lowercase
			else if (islower(word[i]) > 0)
			{
				// increment counter
				lower++;
			}

			// check for other char
			else if (word[i] == '!' || word[i] == '@' || word[i] == '#' || word[i] == '$' || word[i] == '%' || word[i] == '^' || word[i] == '&' || word[i] == '*')
			{
				// increment counter
				other++;
			}
		}

		if (digit == 2 && lower == 2 &&upper == 2 && other==2)
		{
			
			strcpy(string,word);
			flag = 1; 
		}
		else
		{
			printf("SECURITY: Password must contain 2 of each:");
			printf("\n          Digit: 0-9");
			printf("\n          UPPERCASE character");
			printf("\n          lowercase character");
			printf("\n          symbol character: %s",symbols);
		}
		digit = 0, upper = 0, lower = 0, other = 0;
	} while (flag == 0);
}
//F1 to input user account

void getAccount(struct Account *account,int accountnumber)
{
	
	printf("New Account Data (%05d)\n",accountnumber+1);                   
	printf("----------------------------------------\n");
	//accountnumber of user

	account->accountnum = accountnumber + 1;
	
	//Prompts the user to enter the account type.
	printf("Enter the account type (A=Agent | C=Customer): ");
	account->user = getCharOption("AC");
	//input process ends here -----
	
}

//F2 to input userlogin details from user

void getUserLogin(struct UserLogin *userlogin)
{

	int i,done = 0,flag=0;
	//print statements
	printf("\nUser Login Data Input\n");                 
	printf("----------------------------------------\n"); 

	//Prompts the user to enter the user login ID

	do
	{
		printf("Enter user login (10 chars max): ");
		getCString(userlogin->name, MIN, 10);
		for ( i = 0; userlogin->name[i]!='\0' && done ==0; i++)
		{
			if (isblank(userlogin->name[i]))
			{
				done = -1;
			}
		}
		if (done>=0)
		{
			flag = 1;
		}
		else
		{
			printf("ERROR:   The user login must NOT contain whitespace characters.\n");
		}
		done = 0;
		
	} while (flag==0); 
	

	//Prompts the user to enter the user display name.
	
	printf("Enter the display name (30 chars max): ");
	getCString(userlogin->dispname, MIN,MAX );

	//Prompts the user to enter the user login password.

	passwordcheck(userlogin->password);

	//input process ends here -----
	 
}

//F3 to input demographic details from user
void getDemographic(struct Demographic* demographic)
{
	// process to calc the current date
	int currentyear, maxyear, minyear,i;
	currentyear = currentYear();
	maxyear = currentyear - 110;
	minyear = currentyear - 18;

	//print statements
	printf("\nDemographic Data Input\n");                
	printf("----------------------------------------\n");

	//Prompts the user to enter the account holder's birth year.

	printf("Enter birth year (current age must be between 18 and 110): ");
	demographic->birthyear = getIntFromRange(maxyear, minyear);

	//Prompts the user to enter the household income
	
	printf("Enter the household Income: $");
	demographic->houseincome = getPositiveDouble();

	//Prompts the user to enter the country where account holder lives.

	printf("Enter the country (30 chars max.): ");
	getCString(demographic->country, MIN, MAX);
	for (i = 0; demographic->country[i] != '\0'; i++)
	{
		if (islower(demographic->country[i]))
		{
			demographic->country[i] = toupper(demographic->country[i]);
		}
	}

	//input process ends here -----
	
}


//MILESTONE 4
//update account function 
void updateAccount(struct Account *accounts)
{
	
	int selection;
	do
	{
		printf("\nAccount: %05d - Update Options", accounts->accountnum); //display the acct num
		printf("\n----------------------------------------");
		//menu options
		printf("\n1) Update account type (current value: %c)", accounts->user); //display the char of type
		printf("\n2) Login");
		printf("\n3) Demographics");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 3);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			printf("\nEnter the account type (A=Agent | C=Customer): ");
			accounts->user=getCharOption("AC"); //updating the user type
			break;
		case 2:

			updateUserLogin(&accounts->userlogin);	//calling the userlogin updation
			break;
		case 3:

			updateDemographic(&accounts->demographic); //calling the demographic updation
			break;

		default:
			printf("Error!  invalid selection!\n\n");
			break;
		}
	} while (selection);
	
	putchar('\n');
}

//F2 to update the login
void updateUserLogin(struct UserLogin* login)
{
		int selection;
	do
	{
		printf("\nUser Login: %s - Update Options", login->name); //display the acct num
		printf("\n----------------------------------------");
		//menu options
		printf("\n1) Display name (current value: %s)", login->dispname); //display the char of type
		printf("\n2) Password");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 2);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			printf("\nEnter the display name (30 chars max): ");
			getCString(login->dispname, MIN, MAX);
			break;
		case 2:
			passwordcheck(login->password);		 
			break;

		default:
			printf("\nError!  invalid selection!\n\n");
			break;
		}
	} while (selection);
	
}

//F3 to update the demo

void updateDemographic(struct Demographic* demo)
{
	//vars
	int selection,i;
		
	do
	{
		printf("\nDemographic Update Options");
		printf("\n----------------------------------------");
		//menu options
		printf("\n1) Household Income (current value: $%.2lf)",demo->houseincome); //display the char of type
		printf("\n2) Country (current value: %s)",demo->country);
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 2);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			printf("\nEnter the household Income: $");
			demo->houseincome = getPositiveDouble();
			break;
		case 2:
			printf("\nEnter the country (30 chars max.): ");
			getCString(demo->country, MIN, MAX);
				for (i = 0; demo->country[i] != '\0'; i++)
				{
					if (islower(demo->country[i]))
					{
						demo->country[i] = toupper(demo->country[i]);
					}
				}

			break;

		default:
			printf("\nError!  invalid selection!\n\n");
			break;
		}
	} while (selection);
	
}


