
/*
	==================================================
	 Assignment #2 Milestone #1:
	==================================================
	Name   :Tanishq Talreja
	ID     :126460203
	Email  :ttalreja@myseneca.ca
	Section:NCC
*/

#define _CRT_SECURE_NO_WARNINGS


#include"accountTicketingUI.h"


#include<stdio.h>
#include<string.h>

#define TICKETSFILE "tickets.txt"
#define TICKETSARCFILE "tickets_arc.txt"

//main code for logic starts from here

// MILESTONE #3
//a function to find the ticket number exist or not


//THINGS TO DO
//in acdd message change author as to the person who call it or whose ticket is going on --done
//add that after every 5 message there is pauseexec --done
//add agent menu display things --done
//delete extra newline after pause exet in customer menui --done


int loadTickets(struct Ticket tickets[], int arrSize)
{
	int recCount = 0, fieldCount = 0, i;

	// Read (r) : the file MUST exist; otherwise it fails to open! (return NULL)
	FILE* fp = fopen(TICKETSFILE, "r");

	if (fp != NULL)
	{
		// iterate the file until no more records can be read...
		do
		{
			// Read main record:


			if (&tickets->ticketNum > 0)
			{
				fieldCount = fscanf(fp, "%d|%d|%d|%31[^|]|%d|", &tickets[recCount].ticketNum,
					&tickets[recCount].accountNum, &tickets[recCount].statusofTicket,
					tickets[recCount].subject, &tickets[recCount].numofMessage);

				if (fieldCount == 5)
				{
					// Read the Reviews if there are any...
					if (tickets[recCount].numofMessage > 0)
					{
						for (i = 0; i < tickets[recCount].numofMessage; i++)
						{
							fieldCount = fscanf(fp, "%c|%31[^|]|%151[^|]|", &tickets[recCount].message[i].accountType,
								tickets[recCount].message[i].messageAuthor, tickets[recCount].message[i].message);
						}
					}

					// discard remaining chars on line including newline character
					while (fgetc(fp) != '\n');
					recCount++;
					// increment to next index
				}



			}

		} while (!feof(fp) && recCount < arrSize);

		fflush(fp); // forces outstanding char's in the input buffer( file) to be read.
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

	return recCount;
}

int loadArcTickets(struct Ticket tickets[], int arrSize)
{
	int recCount = 0, fieldCount = 0, i;

	// Read (r) : the file MUST exist; otherwise it fails to open! (return NULL)
	FILE* fp = fopen(TICKETSARCFILE, "r");

	if (fp != NULL)
	{
		// iterate the file until no more records can be read...
		do
		{
			// Read main record:


			if (&tickets->ticketNum > 0)
			{
				fieldCount = fscanf(fp, "%d|%d|%d|%31[^|]|%d|", &tickets[recCount].ticketNum,
					&tickets[recCount].accountNum, &tickets[recCount].statusofTicket,
					tickets[recCount].subject, &tickets[recCount].numofMessage);

				if (fieldCount == 5)
				{
					// Read the Reviews if there are any...
					if (tickets[recCount].numofMessage > 0)
					{
						for (i = 0; i < tickets[recCount].numofMessage; i++)
						{
							fieldCount = fscanf(fp, "%c|%31[^|]|%[^|]|", &tickets[recCount].message[i].accountType,
								tickets[recCount].message[i].messageAuthor, tickets[recCount].message[i].message);
						}
					}

					// discard remaining chars on line including newline character
					while (fgetc(fp) != '\n');
					recCount++;
					// increment to next index
				}


			}

		} while (!feof(fp) && recCount < arrSize);

		fflush(fp); // forces outstanding char's in the input buffer( file) to be read.
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

	return recCount;
}

int loadArcTicketsMessage(struct Ticket tickets[], int arrSize)
{
	int recCount = 0, fieldCount = 0, i;
	int count = 0;

	// Read (r) : the file MUST exist; otherwise it fails to open! (return NULL)
	FILE* fp = fopen(TICKETSARCFILE, "r");

	if (fp != NULL)
	{
		// iterate the file until no more records can be read...
		do
		{
			// Read main record:


			if (&tickets->ticketNum > 0)
			{
				fieldCount = fscanf(fp, "%d|%d|%d|%31[^|]|%d|", &tickets[recCount].ticketNum,
					&tickets[recCount].accountNum, &tickets[recCount].statusofTicket,
					tickets[recCount].subject, &tickets[recCount].numofMessage);

				if (fieldCount == 5)
				{
					// Read the Reviews if there are any...
					if (tickets[recCount].numofMessage > 0)
					{
						for (i = 0; i < tickets[recCount].numofMessage; i++)
						{
							fieldCount = fscanf(fp, "%c|%31[^|]|%151[^|]|", &tickets[recCount].message[i].accountType,
								tickets[recCount].message[i].messageAuthor, tickets[recCount].message[i].message);
							count++;
						}

					}

					// discard remaining chars on line including newline character
					while (fgetc(fp) != '\n');
					recCount++;
					// increment to next index
				}


			}

		} while (!feof(fp) && recCount < arrSize);

		fflush(fp); // forces outstanding char's in the input buffer( file) to be read.
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

	return count;
}
//functions for tickets to be written and used
void writeArcTicketDataRecords(struct Ticket tickets[], int arrSize, const char* mode)
{
	int i;

	// Append (a): Will create file if not exists..then allows additional data to end of file
	// Write (w) : will ALWAYS recreate the file (empties it!) and allows for writing
	FILE *fp = fopen(TICKETSARCFILE, mode);

	if (fp != NULL)
	{
		for (i = 0; i < arrSize; i++)
		{
			// do the writing for 1 record to data file
			appendTicketDataRecord(fp, &tickets[i]);
		}

		// close the file
		fflush(fp); // manually allows us to push unwritten data immediately to file
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

}

int writeTicketDataRecords( struct Ticket tickets[], int arrSize, const char* mode)
{
	int i;
	int count = 0;
	// Append (a): Will create file if not exists..then allows additional data to end of file
	// Write (w) : will ALWAYS recreate the file (empties it!) and allows for writing
	FILE* fp = fopen(TICKETSFILE, mode);

	if (fp != NULL)
	{
		for (i = 0; i < arrSize; i++)
		{
			if (tickets[i].ticketNum!=0)
			{
				appendTicketDataRecord(fp, &tickets[i]);
				count++;
			}
			
		}

		// close the file
		fflush(fp); // manually allows us to push unwritten data immediately to file
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}
	
}

void appendTicketDataRecord(FILE* fp, struct Ticket* tickets)
{
	int i, recCount = 0;

	// Append (a): Will create file if not exists..then allows additional data to end of file
	// Write (w) : will ALWAYS recreate the file (empties it!) and allows for writing

	int result = 0;

	// Always test pointers for validity
	if (fp != NULL)
	{
		// valid records only
		if (tickets->ticketNum > 0)
		{
			// Field Delimeter: '|' (Pipe symbol)
			result = fprintf(fp, "%d|%d|%d|%s|%d|", tickets[recCount].ticketNum,
				tickets[recCount].accountNum, tickets[recCount].statusofTicket,
				tickets[recCount].subject, tickets[recCount].numofMessage);
			if (result > 0)
			{
				// Loop reviews:
				for (i = 0; result && i < tickets->numofMessage; i++)
				{
					// write a review element ("review type")
					result = fprintf(fp, "%c|%s|%s|", tickets[recCount].message[i].accountType,
						tickets[recCount].message[i].messageAuthor, tickets[recCount].message[i].message);
				}
			}
			// add newline for end of record!!!
			result = fputc('\n', fp);
		}
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}


}

int loadExitTickets() {
	int count = 0;
	char newline;
	FILE* fp = fopen(TICKETSFILE, "r");

	if (fp != NULL)
	{

		newline = getc(fp);
		while (newline != EOF) {
			if (newline == '\n') {
				count++;
			}

			newline = getc(fp);

		}

		fflush(fp);
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

	return count;
}

