/*
==================================================
Assignment #2 Milestone #1:
==================================================
Name : Tanishq Talreja
ID : 126460203
Email : ttalreja@myseneca.ca
Section : NCC
*/

#define _CRT_SECURE_NO_WARNINGS
//LIBS


//Safegaurding header file

#ifndef TICKETINGSYSTEM_H_
#define TICKETINGSYSTEM_H_


#define MAXSTRINGSIZE 150
#define MINSTRINGSIZE 30
#define MAXMESSAGERECORDS 20

//DEFINING THE STRUCTURE FOR MESSAGE type as per documentation

struct Message
{
	char accountType;
	char messageAuthor[MINSTRINGSIZE+1];
	char message[MAXSTRINGSIZE+1];
};

//DEFINIG A STRUCTURE TYPE FRO THE TICKETING
struct Ticket
{
	int ticketNum;
	int accountNum;
	int statusofTicket;
	char subject[MINSTRINGSIZE+1];
	int numofMessage;
	struct Message message[MAXMESSAGERECORDS];
};

//will add new ticket to teh array for customer

// finds the ticket by index num


int loadTickets(struct Ticket tickets[], int arrSize);

//will write data into the archive of tickets
void writeArcTicketDataRecords(struct Ticket tickets[], int arrSize, const char* mode);

// write data into tickets file
int writeTicketDataRecords(struct Ticket tickets[], int arrSize, const char* mode);

// will load the tickets into archive form
int loadArcTicketsMessage(struct Ticket tickets[], int arrSize);
int loadExitTickets();
//will apend ticket data
void appendTicketDataRecord(FILE* fp, struct Ticket* tickets);
int loadArcTickets(struct Ticket tickets[], int arrSize);
int saveTicketModifications(const struct Ticket tickets[], int arrSize);

#endif // !TICKETINGSYSTEM_H_
