
/*
	==================================================
	 Assignment #2 Milestone #1:
	==================================================
	Name   :Tanishq Talreja
	ID     :126460203
	Email  :ttalreja@myseneca.ca
	Section:NCC
*/
#define _CRT_SECURE_NO_WARNINGS
//I/O lib
#include <stdio.h>
#include<string.h>
//for structure passsing
#include"account.h"
#include "accountTicketingUI.h"
#include "ticket.h"
//MAIN CODE STARTS FROM HERE ->->->->


//pause exec.
// Pause execution until user enters the enter key
void pauseExecution(void)
{
	printf("<< ENTER key to Continue... >>");
	clearStandardInputBuffer();
	putchar('\n');
}
//F1 to display header for summ

void  displayAccountSummaryHeader(void)
{
	printf("\nAcct# Acct.Type Birth\n");
	printf("----- --------- -----\n");
}

//F2 display header for the whole data
void displayAccountDetailHeader(void)
{
	//  formatting 
	printf("Acct# Acct.Type Birth Income      Country    Disp.Name       Login      Password\n");
	printf("----- --------- ----- ----------- ---------- --------------- ---------- --------\n");
}


//header to display the header 
 void AgentTicketHeader(void)
{
	printf("------ ----- --------------- ------ ------------------------------ --------");
	printf("\nTicket Acct# Display Name    Status Subject                        Messages");
	printf("\n------ ----- --------------- ------ ------------------------------ --------");

}
//F3 to display the data for the summ up

void displayAccountSummaryRecord(const struct Account *account)
{
	//print statment

	printf("%05d %-9s %5d\n",account->accountnum, account->user == 'A' ? "AGENT" : "CUSTOMER",
							account->demographic.birthyear);
}

//F4 display the whole data

void displayAccountDetailRecord(const struct Account* account)
{
	int i;
	//print statements
	printf("%05d %-9s %5d $%10.2lf %-10s %-15s %-10s ", account->accountnum,
		account->user == 'A' ? "AGENT" : "CUSTOMER",
		account->demographic.birthyear,account->demographic.houseincome,account->demographic.country,
		account->userlogin.dispname,account->userlogin.name);

	//print loop for password
	for ( i = 0; account->userlogin.password[i] != '\0'; i++)
	{
		if (i % 2 == 1)
		{
			putchar('*');
		}
		else
		{
			printf("%c",account->userlogin.password[i]);
		}
	}
	putchar('\n');


}



//func to display the summary of records

void displayAllAccountSummaryRecords(const struct Account acc[], int size)
{
	int i;
	
	displayAccountSummaryHeader();

	for (i = 0; i < size ; i++) //loop till i<size and the array of accountnum is > 0
	{	//passing the array element by element to the funct
		
		if (acc[i].accountnum==0)
		{
			//do nothing
		}
		else
		{
			displayAccountSummaryRecord(&acc[i]);
		}
	}
	putchar('\n');
	pauseExecution();


}
//F5 display the detailed rec
void displayAllAccountDetailRecords(const struct Account acc[], int size)
{
	int i;
	putchar('\n');
	displayAccountDetailHeader();
	for (i = 0; i < size; i++) //loop till i<size and the array of accountnum is > 0
	{
		if (acc[i].accountnum == 0)
		{
			//do nothing
		}
		else
		{
			displayAccountDetailRecord(&acc[i]);
		}//passing the array element by element to the funct
		
	}
	putchar('\n');
	pauseExecution();

}

int findAccountIndexByAcctNum(int accountnum, const struct AccountTicketingData* accountTicketing, int input)
{
	int  i, find = 0, addr = 0;
	if (input == 1)
	{
		printf("\nEnter the account#: ");
		accountnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->ACCOUNT_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->accounts[i].accountnum==accountnum)
			{
				addr = i;
				find = 1;

			}
		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	else if (input == 0)
	{
		for (i = 0; i < accountTicketing->ACCOUNT_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->accounts[i].accountnum == accountnum)
			{
				find = 1;
				addr = i;
			}
		}
		if (find == 0)
		{
			addr = -1;
		}

	}

	return addr;
}


//MILESTONE 4 Starts


void menuAgent(struct AccountTicketingData* accountTicketing, const struct Account accounts[])
{
	//vars
	int selection, j, found = 0, accountnumber, search = -1;
	char delete;
	int addacount,maxaccount=0,ticketnum,recsloaded=0,accrecs=0,messagenum=0;

	do
	{
			
		//display name of agent
		printf("AGENT: %s (%05d)", accounts->userlogin.dispname, accounts->accountnum);
		//display menu option
		printf("\n==============================================");
		printf("\nAccount Ticketing System - Agent Menu");
		printf("\n==============================================");
		printf("\n 1) Add a new account");
		printf("\n 2) Modify an existing account");
		printf("\n 3) Remove an account");
		printf("\n 4) List accounts: summary view");
		printf("\n 5) List accounts: detailed view");
		printf("\n----------------------------------------------");
		printf("\n 6) List new tickets");
		printf("\n 7) List active tickets");
		printf("\n 8) List closed tickets");
		printf("\n 9) Manage a ticket");
		printf("\n10) Archive closed tickets");
	printf("\n----------------------------------------------");
		printf("\n11) View archived account statistics");
		printf("\n12) View archived tickets statistics");
		printf("\n----------------------------------------------");
		printf("\n0) Logout\n");
		printf("\nSelection: ");
		//input and clearing buffer
		selection = getIntFromRange(0, 12);

		//switch case for menu
		switch (selection)
		{
		case 0:
			
			writeAccountDataRecords(accountTicketing->accounts, accountTicketing->ACCOUNT_MAX_SIZE, "w");
			recsloaded= writeTicketDataRecords(accountTicketing->tickets, accountTicketing->TICKET_MAX_SIZE,"w");
			//recsloaded = loadExitTickets();
			accrecs = loadExitAccounts();
			printf("\nSaving session modifications...\n");
			printf("   %d account saved.\n", accrecs);
			printf("   %d tickets saved.", recsloaded);			
			printf("\n### LOGGED OUT ###\n\n");
			//do nothing
			break;
		case 1:
			//logic for adding new account
			//binary search for acct num =0
			for (j = 0; j < accountTicketing->ACCOUNT_MAX_SIZE && found == 0; j++)
			{
				if (accountTicketing->accounts[j].accountnum == 0)
				{
					addacount = j;
					found = 1;
				}
			}
			
			//loop to search biggest account num
			for (j = 0; j < accountTicketing->ACCOUNT_MAX_SIZE ; j++)
			{
				if (accountTicketing->accounts[j].accountnum>maxaccount)
				{
					maxaccount = accountTicketing->accounts[j].accountnum;
				}
			}
			if (found == 0)
			{
				printf("\nERROR: Account listing is FULL, call ITS Support!\n");
			}
			else
			{
				putchar('\n');
				getAccount(&accountTicketing->accounts[addacount],maxaccount);
				getUserLogin(&accountTicketing->accounts[addacount].userlogin);
				getDemographic(&accountTicketing->accounts[addacount].demographic);
				printf("\n*** New account added! ***\n");
			}
			
			putchar('\n');
			pauseExecution();
			found = 0;

			break;
		case 2:
			//logic to update account and if not valid acctnum display error msg
			search = findAccountIndexByAcctNum(search,accountTicketing,1);
			//display error if !found
			if (search == -1)
			{
				printf("\n Error : Match not found!");
			}
			else
			{
				updateAccount(&accountTicketing->accounts[search]);
			}
			break;
		case 3:
			//input acc num and search for it
			
			printf("\nEnter the account#: ");
			accountnumber = getPositiveInteger();
			//binary search
			if (accounts->accountnum == accountnumber)
			{
				printf("\nERROR: You can't remove your own account!\n\n");
				pauseExecution();
			}
			else if (accounts->accountnum != accountnumber)
			{
				search = findAccountIndexByAcctNum(accountnumber, accountTicketing, 0);
				
				if (search == -1)
				{
					printf("\n Error : Match not found!\n\n");
				}
				else
				{

					displayAccountDetailHeader();
					displayAccountDetailRecord(&accountTicketing->accounts[search]);

					printf("\nAre you sure you want to remove this record? ([Y]es|[N]o): ");
					delete = getCharOption("YN");
					if (delete == 'N')
					{
						printf("\n*** No changes made! ***\n\n");
						pauseExecution();
					}

					else
					{
												
						writeArcAccDataRecords(&accountTicketing->accounts[search], 1, "a");
						accountTicketing->accounts[search].accountnum = 0;
					for ( j = 0; j < accountTicketing->TICKET_MAX_SIZE; j++)
						{
							if (accountTicketing->tickets[j].accountNum== accountnumber && accountTicketing->tickets[j].statusofTicket==1)
							{
								
								accountTicketing->tickets[j].ticketNum = 0; //set ticketnum as 0 so it won't be visible
							}
							else if(accountTicketing->tickets[j].accountNum == accountnumber && accountTicketing->tickets[j].statusofTicket == 0)
							{
								writeArcTicketDataRecords(&accountTicketing->tickets[j], 1, "a");
								accountTicketing->tickets[j].ticketNum = 0;
							}
						}
											
						printf("\n*** Account Removed! ***\n\n");
						pauseExecution();
					}
				}
			}
			//if record found display header and ask for deletion
			break;

		case 4:
			displayAllAccountSummaryRecords(accountTicketing->accounts, accountTicketing->ACCOUNT_MAX_SIZE);
			break;

		case 5:
			displayAllAccountDetailRecords(accountTicketing->accounts, accountTicketing->ACCOUNT_MAX_SIZE);
			break;

		case 6:
			putchar('\n');
			DisplayNewTickets(accountTicketing);
			
			break;
		case 7:
			putchar('\n');
			DisplayAllActiveTickets(accountTicketing);
			
			break;
		case 8:
			putchar('\n');

			displayClosedTickets(accountTicketing);
			break;
		case 9:
			ticketnum = findTicketIndexByAcctNum(accountTicketing, -1);
			search = findAccountIndexByAcctNum(accounts->accountnum, accountTicketing, 0);
			if (ticketnum < 0)
			{
				printf("\nERROR: Invalid ticket number - you may only modify your own ticket.\n\n");

			}
			else
			{
				agentTicketManage(&accountTicketing->tickets[ticketnum],&accountTicketing->accounts[search]);
			}
			break;
		
		case 10:
			
			printf("\nAre you sure? This action cannot be reversed. ([Y]es|[N]o): ");
			delete = getCharOption("YN");
			if (delete=='Y')
			{
				for (j = 0; j < accountTicketing->TICKET_MAX_SIZE; j++)
				{
					if (accountTicketing->tickets[j].statusofTicket == 0)
					{
						writeArcTicketDataRecords(&accountTicketing->tickets[j], 1, "a");
						accountTicketing->tickets[j].ticketNum = 0;//set ticketnum as 0 so it won't be visible
						recsloaded++;
					}
				}
				
				printf("\n*** %d tickets archived ***\n\n", recsloaded-1);
			}
			pauseExecution();
			break;
		case 11:
			accrecs = 0;
			accrecs = loadArcAccounts();
			printf("\nThere are %d account(s) currently archived.\n\n", accrecs);
			pauseExecution();
			break;
		case 12:
			recsloaded = 0;
			recsloaded = loadArcTickets(accountTicketing->tickets, accountTicketing->TICKET_MAX_SIZE);
			messagenum = 0;
				messagenum =	loadArcTicketsMessage(accountTicketing->tickets, accountTicketing->TICKET_MAX_SIZE);
			printf("\nThere are %d ticket(s) and a total of %d message(s) archived.\n\n", recsloaded,messagenum);
			pauseExecution();
			break;
		
		default:
			printf("Error!  invalid selection!\n\n");
			break;
		}
	} while (selection);
	
}

int menuLogin(const struct AccountTicketingData *accountTicketing)
{
	//vars 
	int selection=0, search=0, position=0;
	char input;
	do
	{
		//Display login menu
		printf("==============================================\n");
		printf("Account Ticketing System - Login\n");
		printf("==============================================\n");
		printf("1) Login to the system\n");
		printf("0) Exit application\n");
		printf("----------------------------------------------\n\n");
		printf("Selection: ");

		// call commonhelpers function for range thing
		selection = getIntFromRange(0, 1);

		//if returned selection =1 then ask for acct num.

		if (selection == 1)
		{
			search=AuthenticationCheck(accountTicketing);
			if (search > -1)
			{
				position = search;
				selection = -1;

			}
			
		}
		//if user selects 0 then it will return -1
		else if (selection==0)
		{
			printf("\nAre you sure you want to exit? ([Y]es|[N]o): ");
			input = getCharOption("yYnN");
			if (input=='Y' || input == 'y')
			{
				position = -1;
				selection = -1;

			}
			else
			{
				selection = 0;
			}
			putchar('\n');
		}
		
		//loops exit when found=1 or selection =0
	} while (selection>=0);
	
	return position;
}

//menu for customer 
void menuCustomer(struct AccountTicketingData* accountTicketing, struct Account accounts[])
{
	int selection,search,accountnum,ticketnum=-1;
	int recsLoaded;
	
	do
	{
		//display name of agent
		printf("CUSTOMER: %s (%05d)",accounts->userlogin.dispname,accounts->accountnum );
		//display menu option
		printf("\n==============================================");
		printf("\nCustomer Main Menu");
		printf("\n==============================================");
		printf("\n1) View your account detail");
		printf("\n2) Create a new ticket");
		printf("\n3) Modify an active ticket");
		printf("\n4) List my tickets");
		printf("\n----------------------------------------------");
		printf("\n0) Logout\n");
		printf("\nSelection: ");
		selection = getIntFromRange(0, 4);
		switch (selection)
		{
		case 1:
			search = findAccountIndexByAcctNum(accounts->accountnum, accountTicketing, 0);
			putchar('\n');
			displayAccountDetailHeader();
			displayAccountDetailRecord(&accountTicketing->accounts[search]);
			putchar('\n');
			pauseExecution();
			break;
		case 2:
			search = findAccountIndexByAcctNum(accounts->accountnum, accountTicketing, 0);
			newCustomerTicket(&accountTicketing->accounts[search],accountTicketing->tickets,accountTicketing->TICKET_MAX_SIZE);
			break;
		case 3:
			
			ticketnum= findTicketIndexByAcctNum(accountTicketing,accounts->accountnum);
			search = findAccountIndexByAcctNum(accounts->accountnum, accountTicketing, 0);
			if (ticketnum<0)
			{
				printf("\nERROR: Invalid ticket number - you may only modify your own ticket.\n\n");
				
			}
			else if (accountTicketing->tickets[ticketnum].statusofTicket==0)
			{
				printf("\nERROR: Ticket is closed - changes are not permitted.\n\n");
			}
			
			else 
			{
				activeTicketMenu(&accountTicketing->tickets[ticketnum], &accountTicketing->accounts[search]);
			}
			pauseExecution();
			break;
		case 4:
			accountnum = accounts->accountnum;
			putchar('\n');
			customertickets(accountTicketing, accountnum);
			break;
		
		case 0:
			//do nothing
			writeTicketDataRecords(accountTicketing->tickets, accountTicketing->TICKET_MAX_SIZE, "w");
			recsLoaded = loadTickets(accountTicketing->tickets,accountTicketing->TICKET_MAX_SIZE);
			printf("\nSaving session modifications...\n");
			printf("   %d tickets saved.",recsLoaded);
			printf("\n### LOGGED OUT ###\n\n");
			break;

		default:printf("\nERROR\n");
			break;
		}
	} while (selection);
}



//F1 for app start
void applicationStartup(struct AccountTicketingData *accountTicketing)
{
	int position,flag=0;
	do
	{
		
		position = menuLogin(accountTicketing);

		if (position < 0)
		{
			printf("==============================================");
			printf("\nAccount Ticketing System - Terminated");
			printf("\n==============================================\n");
			flag = 1;
		}

		if (position >= 0)
		{


			if (accountTicketing->accounts[position].user == 'A')
			{
				
				putchar('\n');
				menuAgent(accountTicketing, &accountTicketing->accounts[position]); 
				
			}

			else 
			{
				putchar('\n');
				menuCustomer(accountTicketing, &accountTicketing->accounts[position]);
				
			}

		}
		
	} while (flag==0);
	
	
	
	
}

//User aunthentication
int AuthenticationCheck(const struct AccountTicketingData *accountTicketing)
{	
	int accountnum,search=-1,chance=3,i;
	char inputusername[MIN_ARR_SIZE];
	char inputpass[MIN_ARR_SIZE];
	
	do
	{
		printf("\nEnter the account#: ");
		accountnum = getInteger();
		for ( i = 0; i < accountTicketing->ACCOUNT_MAX_SIZE; i++)
		{
			if (accountTicketing->accounts[i].accountnum==accountnum)
			{
				search = i;
			}
		}
		
		printf("User Login    : ");
		scanf("%[^\n]", inputusername);
		
		printf("Password      : ");
		scanf("%s", inputpass);
		clearStandardInputBuffer();

		if (search>=0)
		{
			if ((strcmp(accountTicketing->accounts[search].userlogin.password,inputpass) == 0 && strcmp(accountTicketing->accounts[search].userlogin.name,inputusername) == 0))
			{
				chance = -1;
			}
			else
			{
				chance--;
				printf("INVALID user login/password combination! [attempts remaining:%d]\n", chance);
			}
		}

		else if(chance>0)
		{
			chance--;
			printf("INVALID user login/password combination! [attempts remaining:%d]\n", chance);
		}
		 if (chance==0)
		{
			
			printf("\nERROR:  Login failed!\n\n");
			pauseExecution();
			search = -1;
			
		}
	} while (chance > 0);
	return search;
}


//function for customer to check his tickets
void customertickets(const struct AccountTicketingData* accountTicketing,int accountnum)
{
	int selection,i;
	//header
	do
	{
		
		printf("------ ------ ------------------------------ --------\n");
		printf("Ticket Status Subject                        Messages");
		printf("\n------ ------ ------------------------------ --------");
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].accountNum == accountnum)
			{
				
				printf("\n%06d %-6s %-33s %2d", accountTicketing->tickets[i].ticketNum, accountTicketing->tickets[i].statusofTicket == 1 ? "ACTIVE" : "CLOSED", accountTicketing->tickets[i].subject, accountTicketing->tickets[i].numofMessage);
			}
		}
		printf("\n------ ------ ------------------------------ --------\n");
		selection = DisplayTicketDetails(accountTicketing, accountnum, 0);
		
	} while (selection <= -1);
	
	
}


//header for tickets


//
void DisplayNewTickets(const struct AccountTicketingData* accountTicketing)
{
	int i, ticketnum;
	int fakeaccountnum = 0;
	do
	{
		AgentTicketHeader();
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].statusofTicket == 1 && accountTicketing->tickets[i].numofMessage == 1 && accountTicketing->tickets->ticketNum > 0) //print the tickets with status of open and number of messages ==1
			{
				printf("\n%06d %05d %-15s ACTIVE %-33s %2d", accountTicketing->tickets[i].ticketNum, accountTicketing->tickets[i].accountNum, accountTicketing->tickets[i].message->messageAuthor, accountTicketing->tickets[i].subject, accountTicketing->tickets[i].numofMessage);
							}
		
		}//loop runs till the every open ticket is previewed.
		printf("\n------ ----- --------------- ------ ------------------------------ --------\n");

		ticketnum = DisplayTicketDetails(accountTicketing, fakeaccountnum, 1);
	} while (ticketnum<=-1);
}


//function to ask for ticket and display the work
int DisplayTicketDetails(const struct AccountTicketingData* accountTicketing,int accountnum,int option)
{
	int ticketnum,i,find=0,search=-1;
	
	if (option == 1)
	{


		printf("\nEnter the ticket number to view the messages or");//ask for the input
		printf("\n0 to return to previous menu: ");


		ticketnum = getTicketNumber();//send the ticketnum to verify its either 0 or a ticketnum


		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->tickets[i].ticketNum == ticketnum)
			{
				search = i;
				find = 1;

			}
		}
		if (ticketnum == 0)
		{
			search = 1;
			find = 1;
			putchar('\n');
		}

		else if (search >= 0)
		{

			printf("\n================================================================================");
			printf("\n%06d (%s) Re: %s\n", accountTicketing->tickets[search].ticketNum, accountTicketing->tickets[search].statusofTicket == 1 ? "ACTIVE" : "CLOSED", accountTicketing->tickets[search].subject);
			printf("================================================================================\n");

			for (i = 0; i < accountTicketing->tickets[search].numofMessage; i++)
			{
				if ((i+1)%5==0)
				{
					
					printf("%s (%s):", accountTicketing->tickets[search].message[i].accountType == 'A' ? "AGENT" : "CUSTOMER", accountTicketing->tickets[search].message[i].messageAuthor);
					printf("\n   %s\n\n", accountTicketing->tickets[search].message[i].message);
					pauseExecution();
					
				}
				else
				{
					printf("%s (%s):", accountTicketing->tickets[search].message[i].accountType == 'A' ? "AGENT" : "CUSTOMER", accountTicketing->tickets[search].message[i].messageAuthor);
					printf("\n   %s\n\n", accountTicketing->tickets[search].message[i].message);
				}
			}
			if (accountTicketing->tickets[search].numofMessage % 5 != 0)
			{
				
				pauseExecution();
			}
			search = -1;

		}

		else
		{
			printf("\nERROR: Invalid ticket number - you may only access your own tickets.\n\n");
			pauseExecution();
		}
	}
	
	else
	{

		printf("\nEnter the ticket number to view the messages or");//ask for the input
		printf("\n0 to return to previous menu: ");


		ticketnum = getTicketNumber();//send the ticketnum to verify its either 0 or a ticketnum


		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE && find == 0; i++)
		{
			if (accountTicketing->tickets[i].accountNum == accountnum)
			{
				if (accountTicketing->tickets[i].ticketNum == ticketnum)
				{
					search = i;
					find = 1;

				}
			}
		}
		if (ticketnum == 0)
		{
			search = 1;
			find = 1;
			putchar('\n');
		}

		else if (search >= 0)
		{

			printf("\n================================================================================");
			printf("\n%06d (%s) Re: %s\n", accountTicketing->tickets[search].ticketNum, accountTicketing->tickets[search].statusofTicket == 1 ? "ACTIVE" : "CLOSED", accountTicketing->tickets[search].subject);
			printf("================================================================================\n");

			for (i = 0; i < accountTicketing->tickets[search].numofMessage; i++)
			{
				if ((i + 1) % 5 == 0)
				{

					printf("%s (%s):", accountTicketing->tickets[search].message[i].accountType == 'A' ? "AGENT" : "CUSTOMER", accountTicketing->tickets[search].message[i].messageAuthor);
					printf("\n   %s\n\n", accountTicketing->tickets[search].message[i].message);
					pauseExecution();

				}
				else
				{
					printf("%s (%s):", accountTicketing->tickets[search].message[i].accountType == 'A' ? "AGENT" : "CUSTOMER", accountTicketing->tickets[search].message[i].messageAuthor);
					printf("\n   %s\n\n", accountTicketing->tickets[search].message[i].message);
				}
			}
			if (accountTicketing->tickets[search].numofMessage % 5 != 0)
			{

				pauseExecution();
			}
			search = -1;

		}

		else
		{
			printf("\nERROR: Invalid ticket number - you may only access your own tickets.\n\n");
			pauseExecution();
		}
	}

	return search;
}

//display all the tickets that have status open
void DisplayAllActiveTickets(const struct AccountTicketingData* accountTicketing)
{
	int i, ticketnum;
	int fakeaccountnum = 0;

	do
	{
		AgentTicketHeader();
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].statusofTicket == 1 && accountTicketing->tickets[i].ticketNum > 0) //print the tickets with status of open and number of messages ==1
			{
				printf("\n%06d %05d %-15s ACTIVE %-33s %2d", accountTicketing->tickets[i].ticketNum, accountTicketing->tickets[i].accountNum, accountTicketing->tickets[i].message->messageAuthor, accountTicketing->tickets[i].subject, accountTicketing->tickets[i].numofMessage);
				
			}
		}//loop runs till the every open ticket is previewed.
		printf("\n------ ----- --------------- ------ ------------------------------ --------\n");
		ticketnum = DisplayTicketDetails(accountTicketing,fakeaccountnum,1);
	} while (ticketnum <= -1);
	
}

void displayClosedTickets(const struct AccountTicketingData* accountTicketing)
{

	int i, ticketnum;
	int fakeaccountnum = 0;

	do
	{
		AgentTicketHeader();
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].statusofTicket == 0 && accountTicketing->tickets[i].ticketNum > 0) //print the tickets with status of open and number of messages ==1
			{
				printf("\n%06d %05d %-15s CLOSED %-33s %2d", accountTicketing->tickets[i].ticketNum, accountTicketing->tickets[i].accountNum, accountTicketing->tickets[i].message->messageAuthor, accountTicketing->tickets[i].subject, accountTicketing->tickets[i].numofMessage);

			}
		}//loop runs till the every open ticket is previewed.
		printf("\n------ ----- --------------- ------ ------------------------------ --------\n");
		ticketnum = DisplayTicketDetails(accountTicketing, fakeaccountnum, 1);
	} while (ticketnum <= -1);
}

//function to load the records of the txt file

int findTicketIndexByAcctNum(const struct AccountTicketingData* accountTicketing, int accountnum)
{
	int  i, find = 0, addr = 0;
	int ticketnum;


	if (accountnum == -1)
	{
		printf("\nEnter ticket number: ");
		ticketnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{

			if (accountTicketing->tickets[i].ticketNum == ticketnum)
			{
				addr = i;
				find = 1;

			}


		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	else
	{
		printf("\nEnter ticket number: ");
		ticketnum = getPositiveInteger();

		//binary search loop for find of acc num
		for (i = 0; i < accountTicketing->TICKET_MAX_SIZE; i++)
		{
			if (accountTicketing->tickets[i].accountNum == accountnum)
			{
				if (accountTicketing->tickets[i].ticketNum == ticketnum)
				{
					addr = i;
					find = 1;

				}
			}

		}
		if (find == 0)
		{
			addr = -1;
		}
	}
	return addr;
}

//function to create a new ticket and assign value to new ticket
void newCustomerTicket(const struct Account* accounts, struct Ticket* ticket, int size)
{
	//vars
	int i, found = 0, addticket, maxticket = 0;



	//loop to find the empty space for ticketnum
	for (i = 0; i < size; i++)
	{
		if (ticket[i].ticketNum == 0)
		{
			addticket = i;
			found = 1;
		}
	}

	//loop to search biggest ticket num
	for (i = 0; i < size; i++)
	{
		if (ticket[i].ticketNum > maxticket)
		{
			maxticket = ticket[i].ticketNum;
		}
	}
	//if there is no empty space found then reporth the user
	if (found == 0)
	{
		printf("\nERROR: Ticket listing is FULL, call ITS Support!\n\n");
		pauseExecution();
	}
	//keypoints: set status to 1,must enter message and subject,data should be stored at position by addticket,set customer as first message ,save name as by the customer
	else
	{
		printf("\nNew Ticket (Ticket#:%06d)\n", maxticket + 1);
		printf("----------------------------------------\n");

		//ask for the message
		printf("Enter the ticket SUBJECT (30 chars. maximum): ");
		getCString(ticket[addticket].subject, 3, MINSTRINGSIZE);
		printf("\nEnter the ticket message details (150 chars. maximum). Press the ENTER key to submit:\n");
		getCString(ticket[addticket].message->message, 3, MAXSTRINGSIZE);
		//set status of ticket as active
		ticket[addticket].statusofTicket = 1;
		//set autor of message as customer
		ticket[addticket].message->accountType = 'C';
		//set number of message as 1
		ticket[addticket].numofMessage = 1;
		//set the author as the user and account num as accountnumber
		ticket[addticket].accountNum = accounts->accountnum;
		//print the end statement
		ticket[addticket].ticketNum = maxticket + 1;
		//copy the name of autor of message as the user
		strcpy(ticket[addticket].message->messageAuthor, accounts->userlogin.dispname);
		//print the end statement
		printf("\n*** New ticket created! ***\n\n");
		pauseExecution();


	}
}


//a menu to modify the active tickets by the user

void activeTicketMenu(struct Ticket* ticket, struct Account* accounts)
{
	//vars
	int selection;

	do
	{

		//after rcving and checking the ticket
		printf("\n----------------------------------------\n");
		printf("Ticket %06d - Update Options\n", ticket->ticketNum);
		printf("----------------------------------------\n");
		printf("Status  : %s\n", ticket->statusofTicket == 1 ? "ACTIVE" : "CLOSED");
		printf("Subject : %s\n", ticket->subject);
		printf("----------------------------------------\n");
		//after printing the statement now display the menu
		//menu options
		printf("1) Modify the subject");
		printf("\n2) Add a message");
		printf("\n3) Close ticket");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 3);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:
			printf("\nEnter the revised ticket SUBJECT (30 chars. maximum): ");
			getCString(ticket->subject, 3, MINSTRINGSIZE);
			break;
		case 2:
			addMessage(ticket, accounts);

			break;
		case 3:

			if (ticket->statusofTicket == 0)

			{
				printf("\nERROR: Ticket is already closed!\n");
			}
			else
			{
				closeTicket(ticket, accounts); //calling the closing of ticket
				selection = 0;
			}
			break;

		default:
			printf("Error!  invalid selection!\n");
			break;
		}
	} while (selection);

	putchar('\n');
}

//adds message if user wishes to
void addMessage(struct Ticket* ticket,const struct Account* accounts)
{
	int i, search = 0;
	//check whether there are spaces for message as limit is 20 if nummessage = 20 display error else let user enter message
	for (i = 0; i < MAXMESSAGERECORDS && search == 0; i++)
	{
		if (strlen(ticket->message[i].message) == 0)
		{
			search = i;
		}

	}

	if (search > 0)
	{
		//strcpy(ticket->message[search].accountType, accounts->user);
		if (accounts->user == 'C')
		{
			ticket->message[search].accountType = 'C';
		}
		else
		{
			ticket->message[search].accountType = 'A';
		}
		strcpy(ticket->message[search].messageAuthor, accounts->userlogin.dispname);
		printf("\nEnter the ticket message details (150 chars. maximum). Press the ENTER key to submit:\n");
		getCString(ticket->message[search].message, 3, MAXSTRINGSIZE);
		ticket->numofMessage++;
	}

	else
	{
		printf("\nERROR: Message limit has been reached, call ITS Support!\n");

	}
}

//closes ticket for the user

void closeTicket(struct Ticket* ticket, const struct Account* accounts)
{
	char status;
	char endmessage;
	//print to close ticket or not


	printf("\nAre you sure you CLOSE this ticket? ([Y]es|[N]o): ");
	status = getCharOption("YN");
	//print to ask for an end message or not
	if (ticket->numofMessage != MAXMESSAGERECORDS)
	{
		printf("\nDo you want to leave a closing message? ([Y]es|[N]o): ");
		endmessage = getCharOption("YN");
		if (endmessage == 'Y' && ticket->numofMessage != MAXMESSAGERECORDS)
		{
			addMessage(ticket, accounts);
		}
	}
	//only enter message if there is space else display error

	if (status == 'Y')
	{
		ticket->statusofTicket = 0;
	}
	printf("\n*** Ticket closed! ***\n");



}


//a ticket menu system for the agent to change the ticket details
void agentTicketManage(struct Ticket* ticket, struct Account* accounts)
{
	//vars
	int selection;
	char choice;

	do
	{

		//after rcving and checking the ticket
		printf("\n----------------------------------------\n");
		printf("Ticket %06d - Update Options\n", ticket->ticketNum);
		printf("----------------------------------------\n");
		printf("Status  : %s\n", ticket->statusofTicket == 1 ? "ACTIVE" : "CLOSED");
		printf("Subject : %s\n", ticket->subject);
		printf("Acct#   : %d\n", ticket->accountNum);
		printf("Customer: %s\n", ticket->message->messageAuthor);
		printf("----------------------------------------");
		//after printing the statement now display the menu
		//menu options
		printf("\n1) Add a message");
		printf("\n2) Close ticket");
		printf("\n3) Re-open ticket");
		printf("\n0) Done");
		printf("\nSelection: ");

		selection = getIntFromRange(0, 3);


		switch (selection)
		{
		case 0:
			//do nothing
			break;
		case 1:

			if (ticket->statusofTicket == 1)
			{
				addMessage(ticket, accounts);
				
			}
			else
			{
				printf("\nERROR: Ticket is closed - new messages are not permitted.\n");
			}

			break;
		case 2:
			if (ticket->statusofTicket == 0)

			{
				printf("\nERROR: Ticket is already closed!\n");
			}
			else
			{
				closeTicket(ticket, accounts); //calling the closing of ticket
				
			}
			break;
		case 3:

			if (ticket->statusofTicket == 0)
			{
				printf("\nAre you sure you RE-OPEN this closed ticket? ([Y]es|[N]o): ");
				choice = getCharOption("YN");
				if (choice == 'Y')
				{
					ticket->statusofTicket = 1;
					printf("\n*** Ticket re-opened! ***\n");
				}
			}
			else
			{
				printf("\nERROR: Ticket is already active!\n");
			}

			break;

		default:
			printf("Error!  invalid selection!\n");
			break;
		}
	} while (selection);

	putchar('\n');
}


int loadExitAccounts() {
	int count = 0;
	char newline;
	FILE* fp = fopen(ACCOUNTFILE, "r");

	if (fp != NULL)
	{

		newline = getc(fp);
		while (newline != EOF) {
			if (newline == '\n') {
				count++;
			}

			newline = getc(fp);

		}

		fflush(fp);
		fclose(fp);
		fp = NULL;
	}
	else
	{
		puts("ERROR: UNABLE TO ACCESS FILE!!!\n");
	}

	return count;
}