/*
==================================================
Assignment #2 Milestone #1:
==================================================
Name : Tanishq Talreja
ID : 126460203
Email : ttalreja@myseneca.ca
Section : NCC
*/

#define _CRT_SECURE_NO_WARNINGS
#define MAXSTRINGSIZE 151
#define MINSTRINGSIZE 31
//LIBS

//Safegaurding header file

#ifndef TICKETINGSYSTEM_H_
#define TICKETINGSYSTEM_H_
//DEFINING THE STRUCTURE FOR MESSAGE type as per documentation

struct Message
{
	char accountType;
	char messageAuthor[MINSTRINGSIZE];
	char message[MAXSTRINGSIZE];
};

//DEFINIG A STRUCTURE TYPE FRO THE TICKETING
struct Ticket
{
	int ticketNum;
	int accountNum;
	int statusofTicket;
	char subject[MINSTRINGSIZE];
	int numofMessage;
	struct Message message[20];
};



#endif // !TICKETINGSYSTEM_H_
